package edu.miu.cs.cs489.lesson5.booksmgmtcliapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksMgmtCliAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
