Exam Date: Oct-12-2023
Student Name: Sopheary Rin
Student ID: 614133
----------------------------
Completed all tasks:
- TASK A: Using a UML drawing tool (or you may draw by hand on paper and pencil/pen), 
draw the Domain model class diagram, showing the two entities and their relationship, including the multiplicity etc.

- TASK B: Using Apache Maven or Gradle, Implement a Java CLI Application Project.